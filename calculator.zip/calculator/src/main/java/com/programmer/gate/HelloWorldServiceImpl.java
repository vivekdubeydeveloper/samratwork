package com.programmer.gate;
 
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.jws.WebService;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
 
@WebService(endpointInterface = "com.programmer.gate.HelloWorldService")
public class HelloWorldServiceImpl implements HelloWorldService{
	
	@Resource
    WebServiceContext wsctx;
 
         public String sayHello() {
        	 
        	 MessageContext mctx = wsctx.getMessageContext();
        	 
        	 Map http_headers = (Map) mctx.get(MessageContext.HTTP_REQUEST_HEADERS);
             List userList = (List) http_headers.get("Username");
             List passList = (List) http_headers.get("Password");

             String username = "";
             String password = "";
             
             if(userList!=null){
             	//get username
             	username = userList.get(0).toString();
             }
             	
             if(passList!=null){
             	//get password
             	password = passList.get(0).toString();
             }
             
             System.out.println("username="+username+" password="+password);
                return "Hello from Programmer Gate ..";
         }
}