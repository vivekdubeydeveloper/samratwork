package com.calculator.util;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;

public class JsonUtil {

	public static String getJsonString(Object object)  {
		String jsonInString="";
		try {
			ObjectMapper mapper = new ObjectMapper();
			jsonInString = mapper.writeValueAsString(object);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonInString;
	}
}