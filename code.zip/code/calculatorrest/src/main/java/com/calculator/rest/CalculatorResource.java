package com.calculator.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.calculator.Calculator;
import com.calculator.CalculatorSoap;
import com.calculator.bean.Input;
import com.calculator.bean.Output;
import com.calculator.util.JsonUtil;

@Path("/calculate")
public class CalculatorResource {
	
	private static final Logger logger = Logger.getLogger(CalculatorResource.class);
	
	private Calculator calculator = new Calculator();
	private CalculatorSoap calculatorSoap = calculator.getPort(CalculatorSoap.class);
	
	@GET
	@Path("/hello")
	public String test() {
		return "Hello";
	}
	
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Output add(Input input) {
		logger.debug(JsonUtil.getJsonString(input));
		logger.debug("Invoking insequence of add");
		logger.debug("url ="+"http://localhost:8080/calculatorrest/rest/calculate/add");
		return new Output(calculatorSoap.add(input.getFirst(), input.getSecond()));
	}

	@POST
	@Path("/subtract")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Output subtract(Input input) {
		logger.debug(JsonUtil.getJsonString(input));
		logger.debug("Invoking insequence of subtract");
		logger.debug("url ="+"http://localhost:8080/calculatorrest/rest/calculate/subtract");
		
		return new Output(calculatorSoap.subtract(input.getFirst(), input.getSecond()));
	}

	
	@POST
	@Path("/multiply")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Output multiply(Input input) {
		logger.debug(JsonUtil.getJsonString(input));
		logger.debug("Invoking insequence of multiply");
		logger.debug("url ="+"http://localhost:8080/calculatorrest/rest/calculate/multiply");
		return new Output(calculatorSoap.multiply(input.getFirst(), input.getSecond()));
	}

	@POST
	@Path("/divide")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Output divide(Input input) {
		logger.debug(JsonUtil.getJsonString(input));
		logger.debug("Invoking insequence of divide");
		logger.debug("url ="+"http://localhost:8080/calculatorrest/rest/calculate/divide");
		return new Output(calculatorSoap.divide(input.getFirst(), input.getSecond()));
	}

}
