package com.calculator.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Output {

	private int result;
	
	

	public Output(int result) {
		this.result = result;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
	
	
}
