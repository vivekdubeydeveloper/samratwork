package com.calculator.rest.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.calculator.bean.MethodError;
import com.calculator.util.JsonUtil;

public class CalculatorFilter implements Filter {

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpReq=(HttpServletRequest)request;
		HttpServletResponse httpRes=(HttpServletResponse)response;
		if(!httpReq.getMethod().equalsIgnoreCase("POST")) {
			System.out.println("Other than post");
			httpRes.setStatus(405);
			PrintWriter out = httpRes.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			MethodError methodError=new MethodError();
			methodError.setStatus_code("GSB_001");
			methodError.setStatus("HTTP_METHOD_NOT_ALLOWED");
			methodError.setDescription("The requested resource does not support http method other than 'POST'.");
			out.print(JsonUtil.getJsonString(methodError));
			out.flush();
			return;
		}else {
			chain.doFilter(request, response);
		}
		

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}

}
