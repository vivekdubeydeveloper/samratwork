used java1.8
tomcat 8.5


for soap based service url
http://localhost:8080/calculator/calculate?wsdl
sample request

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.calculator.com/">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:add>
         <arg0>12</arg0>
         <arg1>5</arg1>
      </ser:add>
   </soapenv:Body>
</soapenv:Envelope>


for restful services
http://localhost:8080/calculatorrest/rest/calculate/
header:Content-Type:application/json
body:
{
	"first":"9",
	"second":"13"
	
}