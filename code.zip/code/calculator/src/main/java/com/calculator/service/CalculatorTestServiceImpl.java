package com.calculator.service;

import javax.jws.HandlerChain;
import javax.jws.WebService;

import com.calculator.Calculator;
import com.calculator.CalculatorSoap;

@WebService(endpointInterface = "com.calculator.service.CalculatorTestService")
@HandlerChain(file = "handler-chain.xml")
public class CalculatorTestServiceImpl implements CalculatorTestService {

	private Calculator calculator = new Calculator();
	private CalculatorSoap calculatorSoap = calculator.getPort(CalculatorSoap.class);

	@Override
	public int add(int first, int second) {

		return calculatorSoap.add(first, second);
	}

	@Override
	public int subtract(int first, int second) {

		return calculatorSoap.subtract(first, second);
	}

	@Override
	public int multiply(int first, int second) {

		return calculatorSoap.multiply(first, second);
	}

	@Override
	public int divide(int first, int second) {

		return calculatorSoap.divide(first, second);
	}
}