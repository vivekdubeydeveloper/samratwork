package com.calculator.interceptor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.log4j.Logger;

import com.calculator.util.AuthenticationUtil;

public class CalculatorMessageHandler implements SOAPHandler<SOAPMessageContext> {

	private static final Logger logger = Logger.getLogger(CalculatorMessageHandler.class);

	@Override
	public void close(MessageContext arg0) {

	}

	@Override
	public boolean handleFault(SOAPMessageContext arg0) {
		logger.debug("Fault called");
		return false;
	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		boolean forwardRequest = false;
		try {
			Boolean isRequest = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

			if (!isRequest) {
				logger.debug("CalculatorTestService - insequence called");
				@SuppressWarnings("unchecked")
				Map<String, List<String>> headers = (Map<String, List<String>>) context
						.get(MessageContext.HTTP_REQUEST_HEADERS);
				String authString = ((List<String>) headers.get("Authorization")).get(0);
				//Basic d3NvMl90ZXN0X3VzcjpQQHNzd0ByZDEyMw==
				if (AuthenticationUtil.isUserAuthenticated(authString)) {
					logger.debug("CalculatorTestService - outsequence called");
					forwardRequest = true;
				} else {
					logger.debug("Not Authenticated");
					SOAPMessage soapMsg = context.getMessage();
					SOAPBody soapBody = soapMsg.getSOAPPart().getEnvelope().getBody();
			          SOAPFault soapFault = soapBody.addFault();
			          soapFault.setFaultCode("401");
			          soapFault.setFaultString("Unauthorized");
			         // HttpServletResponse response = (HttpServletResponse) context.get(SOAPMessageContext.SERVLET_RESPONSE); 
			         // response.sendError(401,"Unauthorized");
			          throw new SOAPFaultException(soapFault); 
					
				}
			} else {
				SOAPMessage soapMsg = context.getMessage();
				logger.debug("Payload: ");
				ByteArrayOutputStream baos = new ByteArrayOutputStream();

				soapMsg.writeTo(baos);
				logger.debug(baos);

			}

		} catch (SOAPException | IOException e) {
			logger.error("Error in :",e);
		}

		return forwardRequest;
	}

	@Override
	public Set<QName> getHeaders() {
		return null;
	}

}
