package com.calculator.util;

import java.util.Base64;

import org.apache.log4j.Logger;

public class AuthenticationUtil {

	private static final  Logger logger = Logger.getLogger(AuthenticationUtil.class);	
	public static boolean isUserAuthenticated(String authString) {
		boolean isUserAuthenticated = false;
		
		String[] authStringA = authString.split(" ");
		String decoded = new String(Base64.getDecoder().decode(authStringA[1]));
		

		String[] userDetails = decoded.split(":");
		
		logger.debug("username=" + userDetails[0]+" password="+userDetails[1]);
		
		if (userDetails[0].equalsIgnoreCase("wso2_test_usr") && userDetails[1].equalsIgnoreCase("P@ssw@rd123")) {
			isUserAuthenticated = true;
		}

		return isUserAuthenticated;
	}
}
