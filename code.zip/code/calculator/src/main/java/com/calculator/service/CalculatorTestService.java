package com.calculator.service;
 
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
 
@WebService
@SOAPBinding(style = Style.RPC)
public interface CalculatorTestService {
 
         @WebMethod
         public int add( @WebParam int first,@WebParam int second);
         
         @WebMethod
         public int subtract( @WebParam int first,@WebParam int second);
         
         @WebMethod
         public int multiply( @WebParam int first,@WebParam int second);
         
         @WebMethod
         public int divide( @WebParam int first,@WebParam int second);
}