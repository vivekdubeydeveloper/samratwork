package com.testproject.s3client;

import java.io.File;
import java.io.IOException;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;
import com.testproject.s3client.util.PropertyReader;

public class AmazonFileUploadTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new AmazonFileUploadTester().uploadFile();
	}

	public void uploadFile() {

		long sTime = System.currentTimeMillis();
		try {
			System.out.println("start");
			String url = PropertyReader.getProperty("app.url");

			Client client = Client.create();
			WebResource webResource = client.resource(url);
			//final File fileToUpload = new File("C:/vivek/personal/plan/may2017.pdf");
			final File fileToUpload = new File("C:/vivek/personal/plan/abc.zip");
			
			final FormDataMultiPart multiPart = new FormDataMultiPart();
			if (fileToUpload != null) {
				multiPart.bodyPart(new FileDataBodyPart("file", fileToUpload, MediaType.APPLICATION_OCTET_STREAM_TYPE));
				multiPart.field("region", "EU_CENTRAL_1");
				multiPart.field("bucketName", "samratsbucket");
			}

			final ClientResponse response = webResource.type(MediaType.MULTIPART_FORM_DATA_TYPE)
					.post(ClientResponse.class, multiPart);

			// ClientResponse response =
			// webResource.type("application/json").post(ClientResponse.class, input);
			String output = response.getEntity(String.class);
			long eTime = System.currentTimeMillis();

		} catch (IOException e) {
			long eTime = System.currentTimeMillis();
			e.printStackTrace();
		}

	}

}