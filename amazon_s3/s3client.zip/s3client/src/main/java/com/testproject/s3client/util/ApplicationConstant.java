package com.testproject.s3client.util;

public class ApplicationConstant {

	public static final String FILES_NAME="filesName";
	public static final String BASE_PATH="basepath";
	public static final String REGION="region";
	public static final String BUCKET_NAME="bucketName";
	public static final String FILE_PATH="filePath";
	
	public static final String COMPLETE_SUMMARY="Complete Summary";
	public static final String SUCCESS="SUCCESS";
	public static final String FAIL="FAIL";
	
}
