package com.s3.aws.service;

public interface AmazonUploadService {

}
