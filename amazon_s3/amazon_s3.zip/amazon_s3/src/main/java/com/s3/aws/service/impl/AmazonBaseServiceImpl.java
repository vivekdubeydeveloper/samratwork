package com.s3.aws.service.impl;

import com.s3.aws.service.AmazonUploadService;

public class AmazonBaseServiceImpl implements AmazonUploadService{

}
