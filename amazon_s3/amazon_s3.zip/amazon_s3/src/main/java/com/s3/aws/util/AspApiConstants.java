package com.s3.aws.util;

public class AspApiConstants {
	public static final String ERROR_DESC = "error_desc";
	public static final String ERROR_GRP = "error_grp";
	public static final String ERROR_CODE = "error_code";
	public static final String STATUS_CD = "status_cd";
	public static final String STATUS = "status";
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String ERROR = "error";
	public static final String SUCCESS_CODE = "1";
	public static final String ERRORCODE = "0";
	public static final String API_CONNECTION_ERROR = "";
}
