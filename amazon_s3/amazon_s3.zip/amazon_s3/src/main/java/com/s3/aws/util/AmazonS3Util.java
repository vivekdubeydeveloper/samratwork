package com.s3.aws.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.Region;
import com.amazonaws.services.s3.transfer.MultipleFileDownload;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.ObjectMetadataProvider;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.s3.aws.exception.AmazonUploadDownloadException;
import com.s3.aws.model.Amazon;

@Configuration

public class AmazonS3Util {

	public static AmazonS3 getAmazonS3Client(String secretkey, String clientId, Regions regions) throws Exception {
		AmazonS3 s3client = null;
		try {
			AWSCredentials credentials = new BasicAWSCredentials(clientId, secretkey);
			s3client = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials))
					.withRegion(regions).build();

		} catch (Exception e) {
			throw new AmazonUploadDownloadException(e.getMessage());
		}
		return s3client;
	}

	public static DynamoDB getAmazonDynamoDB(String secretkey, String clientId, Regions regions) throws Exception {
		DynamoDB dynamoDB = null;
		try {
			AWSCredentials credentials = new BasicAWSCredentials(clientId, secretkey);
			AmazonDynamoDB client = new AmazonDynamoDBClient(credentials).withRegion(regions);
			dynamoDB = new DynamoDB(client);
		} catch (Exception e) {
			throw new AmazonUploadDownloadException(e.getMessage());
		}
		return dynamoDB;
	}

	@SuppressWarnings("deprecation")
	public static Object multipleFileUpload(String bucketName, String filePath, AmazonS3 s3client) throws Exception {
		File file = new File(filePath);
		List<File> filesList = new ArrayList<File>();
		if (file.exists()) {
			List<Amazon> list = new ArrayList<>();
			if (file.isDirectory()) {
				for (File path : file.listFiles()) {
					filesList.add(path);
					setAmazon(bucketName, filePath, path, s3client.getRegion(), list, null);
				}
			} else {
				filesList.add(file);
				setAmazon(bucketName, filePath, file, s3client.getRegion(), list, null);
			}
			TransferManager xfer_mgr = new TransferManager(s3client);
			MultipleFileUpload xfer = null;
			try {
				if (filesList.size() > 1)
					xfer = xfer_mgr.uploadFileList(bucketName, "", new File(filePath), filesList);
				else
					xfer = xfer_mgr.uploadFileList(bucketName, "", new File(file.getParent()), filesList);
				XferMgrProgress.showTransferProgress(xfer);
				XferMgrProgress.waitForCompletion(xfer);
			} catch (Exception e) {
				throw new AmazonUploadDownloadException(e.getMessage());
			}
			xfer_mgr.shutdownNow();
			return list;

		} else
			throw new AmazonUploadDownloadException("folder doesn't exist please provide a valid  path");

	}

	@SuppressWarnings("deprecation")
	public static Object multipleFileUpload(String bucketName, String filePath, String secretkey, String clientId,
			Regions regions) throws Exception {
		AmazonS3 s3client = getAmazonS3Client(secretkey, clientId, regions);
		File file = new File(filePath);
		List<File> filesList = new ArrayList<File>();
		String docId = getDocid(secretkey, clientId, regions);
		if (file.exists()) {
			List<Amazon> list = new ArrayList<>();
			if (file.isDirectory()) {
				for (File path : file.listFiles()) {
					filesList.add(path);
					setAmazon(bucketName, filePath, path, s3client.getRegion(), list, docId);
				}
			} else {
				filesList.add(file);
				setAmazon(bucketName, filePath, file, s3client.getRegion(), list, docId);
			}
			ObjectMetadataProvider metadataProvider = new ObjectMetadataProvider() {
				public void provideObjectMetadata(File file, ObjectMetadata metadata) {
					if (getFileExtension(file).equals("pdf")) {
						metadata.getUserMetadata().put("pageCount", "" + getPdfByPageNumber(file));
					} else if (getFileExtension(file).equals("zip")) {
						try {
							FileInputStream fis = new FileInputStream(file);
							ZipInputStream zipIs = new ZipInputStream(new BufferedInputStream(fis));
							Integer count = 0;
							while (zipIs.getNextEntry() != null) {
								count++;
							}
							zipIs.close();
							metadata.getUserMetadata().put("pageCount", "" + count);
						} catch (Exception e) {
						}

					}

				}
			};
			TransferManager xfer_mgr = new TransferManager(s3client);
			MultipleFileUpload xfer = null;
			try {
				if (filesList.size() > 1)
					xfer = xfer_mgr.uploadFileList(bucketName, docId, new File(filePath), filesList, metadataProvider);
				else
					xfer = xfer_mgr.uploadFileList(bucketName, docId, new File(file.getParent()), filesList, metadataProvider);
				XferMgrProgress.showTransferProgress(xfer);
				XferMgrProgress.waitForCompletion(xfer);
			} catch (Exception e) {
				throw new AmazonUploadDownloadException(e.getMessage());
			}
			xfer_mgr.shutdownNow();
			return list;

		} else
			throw new AmazonUploadDownloadException("folder doesn't exist please provide a valid  path");

	}

	public static void setAmazon(String bucketName, String filePath, File file, Region region, List<Amazon> list,
			String docId) {
		Amazon amazon = new Amazon();
		amazon.setBucketName(bucketName);
		amazon.setFilePath(filePath);
		amazon.setFileSize(file.length());
		amazon.setFileName(file.getName());
		amazon.setKey(docId + "/" + file.getName());
		amazon.setFileType(getFileExtension(file));
		amazon.setRegion(region.name());
		list.add(amazon);
	}

	public static Object downloadFile(String bucketName, String key, String filePath, AmazonS3 s3client)
			throws Exception {
		File file = new File(filePath);
		if (file.exists()) {
			TransferManager xfer_mgr = new TransferManager(s3client);
			try {
				MultipleFileDownload xfer = (MultipleFileDownload) xfer_mgr.downloadDirectory(bucketName, key, file);
				XferMgrProgress.showTransferProgress(xfer);
				XferMgrProgress.waitForCompletion(xfer);
				xfer_mgr.shutdownNow();
				file = new File(filePath + "/" + key);
				if (file.exists()) {
					Amazon amazon = new Amazon();
					if (file.isDirectory()) {
						amazon.setBucketName(bucketName);
						amazon.setFilePath(file.getPath());
						amazon.setFileName(file.getName());
						amazon.setKey(key);
						amazon.setFileType(getFileExtension(file));
						amazon.setRegion(s3client.getRegion().name());
						List<Map<String, Object>> listMap = new ArrayList<>();
						for (File files : file.listFiles()) {
							Map<String, Object> map = new LinkedHashMap<>();
							map.put("fileName", files.getName());
							map.put("fileSize", files.length());
							map.put("filePath", files.getPath());
							map.put("fileType", getFileExtension(files));
							listMap.add(map);
						}
						amazon.setList(listMap);
					} else {
						amazon.setBucketName(bucketName);
						amazon.setFilePath(file.getPath());
						amazon.setFileName(file.getName());
						amazon.setKey(key);
						amazon.setFileType(getFileExtension(file));
						amazon.setFileSize(file.length());
						amazon.setFile(Files.readAllBytes(file.toPath()));
					}
					return amazon;
				} else
					throw new AmazonUploadDownloadException(
							"amazon s3 folder doesn't exist please provide a valid  path");
			} catch (Exception e) {
				throw new AmazonUploadDownloadException(e.getMessage());
			}

		} else
			throw new AmazonUploadDownloadException("Local folder doesn't exist please provide a valid  path");

	}

	private static String getFileExtension(File file) {
		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		else
			return "";
	}

	public static Integer getPdfByPageNumber(File file) {
		Integer size = 0;
		try {
			PDDocument document = PDDocument.load(file);
			Splitter splitter = new Splitter();
			List<PDDocument> splittedDocuments = splitter.split(document);
			size = splittedDocuments.size();
			document.close();
		} catch (Exception e) {
		}
		return size;

	}
	
	
	public static Integer getPdfPageCount(InputStream is) {
		Integer size = 0;
		try {
			PDDocument document = PDDocument.load(is);
			Splitter splitter = new Splitter();
			List<PDDocument> splittedDocuments = splitter.split(document);
			size = splittedDocuments.size();
			document.close();
		} catch (Exception e) {
		}
		return size;

	}
	
	
	public static Integer getZipPageCount(InputStream is) throws IOException {
		
		ZipInputStream zipIs = new ZipInputStream(new BufferedInputStream(is));
		Integer count = 0;
		while (zipIs.getNextEntry() != null) {
			count++;
		}
		zipIs.close();
		
		return count;
		
	}

	public static synchronized String getDocid(String secretkey, String clientId, Regions regions) {
		AWSCredentials credentials = new BasicAWSCredentials(clientId, secretkey);
		AmazonDynamoDB client = new AmazonDynamoDBClient(credentials).withRegion(regions);
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("wipodocseq");
		int year = table.getItem("docid", 2018).getNumber("seq").intValue();
		year++;
		UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("docid", 2018)
				.withUpdateExpression("set seq = :year").withValueMap(new ValueMap().withNumber(":year", year));
		try {
			table.updateItem(updateItemSpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(year);
		return String.valueOf(year);

	}
	
	
}
