package com.supercon.model;

public class Product {

    private final double price;
    private final String productCode;
    private final String name;
    private double discount;

    public Product(double price, String productCode, String name) {
        this.price = price;
        this.productCode = productCode;
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public double getDiscountedPrice() {
        return price - (price * getDiscount());
    }

    public String getProductCode() {
        return productCode;
    }

    public String getName() {
        return name;
    }

    public double getDiscount() {
        if (this.productCode.startsWith("DIS_10")) {
            return 0.1;
        } else if (this.productCode.startsWith("DIS_15")) {
            return 0.15;
        } else if (this.productCode.startsWith("DIS_20")) {
            return 0.2;
        }
        return 0.0;
    }

}
