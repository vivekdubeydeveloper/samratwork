package com.supercon.model;

public class Customer {

    private String name;

    public Customer(String name) {
        this.name = name;
    }

}
