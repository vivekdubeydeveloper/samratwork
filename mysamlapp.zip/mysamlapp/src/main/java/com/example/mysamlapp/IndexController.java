package com.example.mysamlapp;

import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.NameID;
import org.opensaml.xml.schema.XSString;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

    @RequestMapping("/")
    public String index(Model model) {
    	
    	
    	 Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
         NameID nameId = (NameID) authentication.getPrincipal();
         model.addAttribute("name", nameId.getValue());

         // there be dragons
         Assertion assertion = (Assertion) nameId.getParent().getParent();
         assertion.getAttributeStatements().forEach(attributeStatement -> {
             attributeStatement.getAttributes().forEach(attribute -> {
                 String key = attribute.getName();
                 // cheat a little to not deal with an array/list value
                 String value = ((XSString) attribute.getAttributeValues().get(0)).getValue();
                 model.addAttribute(key, value);
             });
         });
    	
    	/*System.out.println(httpServletRequest.getQueryString());
    	
    	Iterator<String> itr=httpServletRequest.getParameterMap().keySet().iterator();
    	
    	while(itr.hasNext()) {
    		String key=itr.next();
    		System.out.println("key=="+key);
    		System.out.println("key=="+httpServletRequest.getParameterMap().get(key));
    	}*/
    	
        return "index";
    }
    
    
    @RequestMapping("/saml/SSO")
    public String samltest(HttpServletRequest httpServletRequest) {
    	
    	System.out.println(httpServletRequest.getQueryString());
    	
    	Iterator<String> itr=httpServletRequest.getParameterMap().keySet().iterator();
    	
    	while(itr.hasNext()) {
    		String key=itr.next();
    		System.out.println("key=="+key);
    		System.out.println("key=="+httpServletRequest.getParameterMap().get(key));
    	}
    	
        return "index";
    }
    
    @RequestMapping("/saml")
    public String saml() {
        return "saml";
    }
}
