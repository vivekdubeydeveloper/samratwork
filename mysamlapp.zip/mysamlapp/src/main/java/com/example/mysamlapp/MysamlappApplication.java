package com.example.mysamlapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysamlappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysamlappApplication.class, args);
	}

}
